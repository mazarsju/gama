To build the docs for the first time....

LINUX

Make sure you have sphinx setup:
1. sudo apt-get install python-dev 
2. sudo easy_install sphinx

And then do a mvn build:
3. mvn clean install

MAC

Make sure you have sphinx setup:
1. Install the developer tools (there is installer on your operating system disk)
2. easy_install sphinx

And then do a mvn build:
3. mvn clean install

WINDOWS

Not yet
