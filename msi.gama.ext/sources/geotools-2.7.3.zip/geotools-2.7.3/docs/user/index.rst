.. _userguide:

User Guide
==========

.. toctree::
   :hidden:

   quickstart
   examples/index
   faq

The `User Guide Wiki <http://docs.codehaus.org/display/GEOTDOC/Home>`_ is  reference for GeoTools with code examples for each module.

Visit the :ref:`examples` section for tutorial notes and source code that
illustrate some of the common uses of GeoTools.