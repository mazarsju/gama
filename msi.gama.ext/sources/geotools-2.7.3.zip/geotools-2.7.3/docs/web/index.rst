GeoTools The Open Source Java GIS Toolkit
=========================================

GeoTools is an open source Java library that provides tools for 
geospatial data.

.. toctree::
   :hidden:

   getinvolved
   about
