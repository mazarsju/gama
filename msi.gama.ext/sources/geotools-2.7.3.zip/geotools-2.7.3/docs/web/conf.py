import sys, os
sys.path.append(os.path.abspath('..'))
from common import *

html_theme='geotools-web'
html_title='GeoTools'
