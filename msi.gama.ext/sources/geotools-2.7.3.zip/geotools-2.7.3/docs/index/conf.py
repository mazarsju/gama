import sys, os
sys.path.append(os.path.abspath('..'))
from common import *

html_theme='geotools'
html_title='GeoTools Documentation'
