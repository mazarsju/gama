package org.geotools.demo;

import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.io.WKTReader;
import java.awt.Color;
import org.geotools.data.DataStore;
import org.geotools.data.DataUtilities;
import org.geotools.data.memory.MemoryDataStore;

import org.geotools.factory.CommonFactoryFinder;
import org.geotools.feature.simple.SimpleFeatureBuilder;
import org.geotools.geometry.jts.JTSFactoryFinder;
import org.geotools.geometry.jts.ReferencedEnvelope;
import org.geotools.map.DefaultMapContext;
import org.geotools.map.MapContext;
import org.geotools.styling.SLD;
import org.geotools.styling.Stroke;
import org.geotools.styling.Style;
import org.geotools.styling.StyleFactory;
import org.geotools.styling.Symbolizer;
import org.geotools.swing.JMapFrame;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.feature.simple.SimpleFeatureType;
import org.opengis.filter.FilterFactory2;

public class UOMProblem {

    public static void main(String[] args) throws Exception {
        final SimpleFeatureType type = DataUtilities.createType("test", "shape:Polygon,name:String");
        GeometryFactory gf = JTSFactoryFinder.getGeometryFactory(null);
        SimpleFeatureBuilder fb = new SimpleFeatureBuilder(type);
        WKTReader reader = new WKTReader(gf);

        Polygon poly = (Polygon) reader.read("POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))");
        SimpleFeature f1 = fb.buildFeature(null, new Object[]{poly, "square"});

        poly = (Polygon) reader.read("POLYGON((10 0, 15 10, 20 0, 10 0))");
        SimpleFeature f2 = fb.buildFeature(null, new Object[]{poly, "triangle"});
        
        DataStore store = new MemoryDataStore(new SimpleFeature[]{f1, f2});

        MapContext map = new DefaultMapContext();
        map.addLayer(store.getFeatureSource("test"), createStyle());
        map.getViewport().setBounds(new ReferencedEnvelope(-20, 20, -20, 20, null));
        JMapFrame.showMap(map);
    }

    private static Style createStyle() {
        FilterFactory2 ff2 = CommonFactoryFinder.getFilterFactory2(null);
        StyleFactory sf = CommonFactoryFinder.getStyleFactory(null);

        Symbolizer sym = sf.createPolygonSymbolizer(Stroke.NULL, sf.createFill(ff2.literal(Color.CYAN)), null);
        return SLD.wrapSymbolizers(sym);
    }
}