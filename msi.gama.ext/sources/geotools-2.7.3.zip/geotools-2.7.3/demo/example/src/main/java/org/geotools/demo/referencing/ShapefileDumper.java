package org.geotools.demo.referencing;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.geotools.data.DataUtilities;
import org.geotools.data.FeatureStore;
import org.geotools.data.shapefile.ShapefileDataStore;
import org.geotools.data.simple.SimpleFeatureCollection;
import org.geotools.feature.simple.SimpleFeatureBuilder;
import org.geotools.feature.simple.SimpleFeatureTypeBuilder;
import org.geotools.geometry.jts.JTS;
import org.geotools.metadata.iso.citation.Citations;
import org.geotools.referencing.CRS;
import org.geotools.referencing.crs.DefaultGeographicCRS;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.feature.simple.SimpleFeatureType;
import org.opengis.metadata.extent.GeographicBoundingBox;
import org.opengis.referencing.crs.CoordinateReferenceSystem;
import org.opengis.referencing.crs.GeographicCRS;
import org.opengis.referencing.crs.ProjectedCRS;
import org.opengis.referencing.operation.Projection;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LinearRing;
import com.vividsolutions.jts.geom.MultiPolygon;
import com.vividsolutions.jts.geom.Polygon;


public class ShapefileDumper {

    public static void main(String[] args) throws Exception {
        final File root = new File("/tmp/epsg");
        root.mkdir();
        Set<String> codes = CRS.getSupportedCodes("EPSG");
        
        // assuming 4 cores + HT
        ExecutorService executor = Executors.newFixedThreadPool(12);
        
        for (String code : codes) {
            final String epsgCode = code.startsWith("EPSG") ? code : "EPSG:" + code;
            try {
                final CoordinateReferenceSystem crs =  CRS.decode(epsgCode);
                final SimpleFeatureCollection fc = getCRSFeature(crs, epsgCode);
                
                if(fc != null) {
                    executor.submit(new Runnable() {
                        
                        public void run() {
                            try {
                                // fan out files into directories named after the projection to
                                // avoid Windows blowing up when facing them
                                File crsContainer;
                                if(crs instanceof GeographicCRS) {
                                    crsContainer = new File(root, "Geographic");
                                } else if(crs instanceof ProjectedCRS) {
                                    ProjectedCRS projected = (ProjectedCRS) crs;
                                    String projection = projected.getConversionFromBase().getMethod().getName().getCode();
                                    projection = projection.replace(" ", "_").replace("(", "").replace(")", "");
                                    crsContainer = new File(root, projection);
                                } else {
                                    crsContainer = new File(root, "other");
                                }
                                crsContainer.mkdir();
                                
                                Integer num = CRS.lookupEpsgCode(crs, true);
                                int dir = num / 1000 * 1000;
                                File codeContainer = new File(crsContainer, Integer.toString(dir));
                                codeContainer.mkdir();
                                
                                // build the shapefile
                                File shape = new File(codeContainer, "epsg" + num + ".shp");
                                ShapefileDataStore ds = new ShapefileDataStore(shape.toURL());
                                ds.createSchema(fc.getSchema());
                                FeatureStore fs = (FeatureStore) ds.getFeatureSource();
                                fs.addFeatures(fc);
                                ds.dispose();  
                            } catch(Exception e) {
                                e.printStackTrace();
                                System.out.println("Failed to write out " + epsgCode + " :" + e.getMessage());
                            }
                        }
                    });
                }
            } catch(Exception e) {
                // e.printStackTrace();
                System.out.println("Skipping " + epsgCode + " :" + e.getMessage());
            }
        }
        
        System.out.println("Waiting for executor to write all shapefiles");
        executor.shutdown();
        System.out.println("Done!");
    }
    
    static SimpleFeatureCollection getCRSFeature(CoordinateReferenceSystem crs, String epsgCode) throws Exception {
        Geometry poly = getGeographicBoundingBox(crs);
        if(poly == null) {
            return null;
        } else {
            // transform into target crs
            poly = JTS.transform(poly, CRS.findMathTransform(DefaultGeographicCRS.WGS84, crs, true));
        }
        String code = CRS.lookupIdentifier(Citations.EPSG, crs, true).toString();
        String name = CRS.getAuthorityFactory(true).getDescriptionText(epsgCode).toString(Locale.getDefault());
        
        // prepare the feature type we want to buid
        SimpleFeatureTypeBuilder tb = new SimpleFeatureTypeBuilder();
        tb.add("the_geom", MultiPolygon.class, crs);
        tb.add("name", String.class);
        tb.add("remarks", String.class);
        tb.setName(code.replace(":", ""));
        SimpleFeatureType featureType = tb.buildFeatureType();
        
        SimpleFeatureBuilder fb = new SimpleFeatureBuilder(featureType);
        fb.add(poly);
        fb.add(name);
        if(crs.getRemarks() != null) {
            fb.add(crs.getRemarks().toString());
        }
        SimpleFeature sf = fb.buildFeature(null);
        
        return DataUtilities.collection(sf);
    }
    
    static Geometry getGeographicBoundingBox(CoordinateReferenceSystem crs) {
        GeographicBoundingBox envelope = CRS.getGeographicBoundingBox(crs);
        if (envelope == null) {
            return null;
        }

        final double westBoundLongitude = envelope.getWestBoundLongitude();
        final double eastBoundLongitude = envelope.getEastBoundLongitude();
        final double southBoundLatitude = envelope.getSouthBoundLatitude();
        final double northBoundLatitude = envelope.getNorthBoundLatitude();

        final int numSteps = 80;
        Geometry geogBoundingGeom;

        if (westBoundLongitude < eastBoundLongitude) {
            geogBoundingGeom = createBoundingPolygon(westBoundLongitude, eastBoundLongitude,
                    southBoundLatitude, northBoundLatitude, numSteps);
        } else {
            // the geographic bounds cross the day line (lon -180/180), trick it into two adjacent
            // polygons
            Polygon eastPolygon = createBoundingPolygon(-180, eastBoundLongitude,
                    southBoundLatitude, northBoundLatitude, numSteps);

            Polygon westPolygon = createBoundingPolygon(westBoundLongitude, 180,
                    southBoundLatitude, northBoundLatitude, numSteps);

            geogBoundingGeom = new GeometryFactory().createMultiPolygon(new Polygon[] { eastPolygon, westPolygon });
        }
        return geogBoundingGeom;
    }
    
    static  Polygon createBoundingPolygon(final double westBoundLongitude,
            final double eastBoundLongitude, final double southBoundLatitude,
            final double northBoundLatitude, final int numSteps) {
        // build a densified LinearRing so it does reproject better
        final double dx = (eastBoundLongitude - westBoundLongitude) / numSteps;
        final double dy = (northBoundLatitude - southBoundLatitude) / numSteps;

        List<Coordinate> coords = new ArrayList<Coordinate>(4 * numSteps + 1);

        double x = westBoundLongitude;
        for (int i = 0; i < numSteps; i++) {
            coords.add(new Coordinate(x, southBoundLatitude));
            x += dx;
        }
        double y = southBoundLatitude;
        for (int i = 0; i < numSteps; i++) {
            coords.add(new Coordinate(eastBoundLongitude, y));
            y += dy;
        }
        x = eastBoundLongitude;
        for (int i = 0; i < numSteps; i++) {
            coords.add(new Coordinate(x, northBoundLatitude));
            x -= dx;
        }
        y = northBoundLatitude;
        for (int i = 0; i < numSteps; i++) {
            coords.add(new Coordinate(westBoundLongitude, y));
            y -= dy;
        }
        coords.add(new Coordinate(westBoundLongitude, southBoundLatitude));

        Coordinate[] coordinates = coords.toArray(new Coordinate[coords.size()]);
        LinearRing shell = new GeometryFactory().createLinearRing(coordinates);
        Polygon polygon = new GeometryFactory().createPolygon(shell, null);
        return polygon;
    }
}
